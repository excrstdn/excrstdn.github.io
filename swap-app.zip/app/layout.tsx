'use client'
import '@rainbow-me/rainbowkit/styles.css'
import '../styles/globals.css'
import { WagmiConfig, RainbowKitProvider } from '../lib/wallet'
import { config, chains } from '../lib/wallet'

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <WagmiConfig config={config}>
          <RainbowKitProvider chains={chains}>{children}</RainbowKitProvider>
        </WagmiConfig>
      </body>
    </html>
  )
}
