'use client'
import { SwapForm } from '../../components/SwapForm'
import { ConnectButton } from '@rainbow-me/rainbowkit'

export default function SwapPage() {
  return (
    <main className="flex flex-col items-center justify-center min-h-screen p-4 gap-6">
      <ConnectButton />
      <SwapForm />
    </main>
  )
}
