'use client'
import Link from 'next/link'
import { ConnectButton } from '@rainbow-me/rainbowkit'

export default function Home() {
  return (
    <main className="flex flex-col items-center justify-center min-h-screen gap-6">
      <ConnectButton />
      <h1 className="text-3xl font-bold">Swap Testnet</h1>
      <Link href="/swap" className="text-blue-500 underline">Ke Halaman Swap</Link>
    </main>
  )
}
