import { Chain } from 'wagmi'

export const sepolia: Chain = {
  id: 11155111,
  name: 'Sepolia',
  network: 'sepolia',
  nativeCurrency: {
    name: 'ETH',
    symbol: 'SEPETH',
    decimals: 18,
  },
  rpcUrls: {
    default: { http: ['https://sepolia.infura.io/v3/YOUR_KEY'] },
  },
  blockExplorers: {
    default: { name: 'Etherscan', url: 'https://sepolia.etherscan.io' },
  },
  testnet: true,
}

export const monad: Chain = {
  id: 2018,
  name: 'Monad',
  network: 'monad',
  nativeCurrency: {
    name: 'METH',
    symbol: 'METH',
    decimals: 18,
  },
  rpcUrls: {
    default: { http: ['https://rpc.testnet.monad.xyz'] },
  },
  blockExplorers: {
    default: { name: 'MonadScan', url: 'https://explorer.testnet.monad.xyz' },
  },
  testnet: true,
}
