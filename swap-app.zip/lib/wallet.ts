'use client'
import {
  getDefaultWallets,
  RainbowKitProvider,
} from '@rainbow-me/rainbowkit'
import { configureChains, createConfig, WagmiConfig } from 'wagmi'
import { publicProvider } from 'wagmi/providers/public'
import { sepolia, monad } from './chains'

const { chains, publicClient } = configureChains([sepolia, monad], [publicProvider()])

const { connectors } = getDefaultWallets({
  appName: 'Swap Testnet',
  projectId: 'YOUR_WALLETCONNECT_ID',
  chains,
})

export const config = createConfig({
  autoConnect: true,
  connectors,
  publicClient,
})

export { chains, RainbowKitProvider, WagmiConfig }
