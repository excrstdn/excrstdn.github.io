'use client'
import { useState } from 'react'
import { chains } from '../lib/wallet'

export function SwapForm() {
  const [chain, setChain] = useState(chains[0].id)
  const [amount, setAmount] = useState('')

  const handleSwap = () => {
    alert(`Swap pada chain ${chain} sebesar ${amount}`)
  }

  return (
    <div className="bg-white p-6 rounded-xl shadow-md w-[320px]">
      <h2 className="text-xl font-bold mb-4">Swap</h2>
      <select
        className="w-full p-2 border mb-4 rounded"
        value={chain}
        onChange={(e) => setChain(Number(e.target.value))}
      >
        {chains.map((c) => (
          <option key={c.id} value={c.id}>{c.name}</option>
        ))}
      </select>
      <input
        className="w-full p-2 border rounded mb-4"
        type="number"
        value={amount}
        placeholder="Jumlah"
        onChange={(e) => setAmount(e.target.value)}
      />
      <button
        className="w-full p-2 bg-blue-600 text-white rounded hover:bg-blue-700"
        onClick={handleSwap}
      >
        Swap
      </button>
    </div>
  )
}
